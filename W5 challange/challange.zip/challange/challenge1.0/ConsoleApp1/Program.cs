﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {

        static void Main(string[] args)
        {
            bool keeplooping = true;

            while (keeplooping == true)
            {
                Console.WriteLine("");
                Console.WriteLine("Enter number to select");
            Console.WriteLine("");
            Console.WriteLine("1. Create Square");
            Console.WriteLine("2. Create Rectangle");
            Console.WriteLine("");

           

                string Option = Console.ReadLine();

                try
                {



                    if (Option == "1")
                    {
                        Console.WriteLine("Enter color");
                        string color = Console.ReadLine();
                        Console.WriteLine("Enter Side 1");
                        float Side1Length = float.Parse(Console.ReadLine());
                        Square square = new Square(color, Side1Length);
                        Console.WriteLine(square.GetArea());


                        if (Side1Length <= 0)
                        {
                            throw new zeroException();
                        }

                       

                       



                    }
                   
                    

                    else if (Option == "2")
                    {
                        Console.WriteLine("Enter color");
                        string color = Console.ReadLine();
                        Console.WriteLine("Enter Side 1");
                        float Side1Length = float.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Side 2");
                        float Side2Length = float.Parse(Console.ReadLine());
                        Rectangle rectangle = new Rectangle(color, Side1Length, Side2Length);
                        Console.WriteLine(rectangle.GetArea());

                        if (Side1Length <= 0)
                        {
                            throw new zeroException();
                        }
                        if (Side2Length <= 0)
                        {
                            throw new zeroException();
                        }

                       

                      
                    }
                }




                catch (zeroException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (FormatException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                




            }
        }

        
        public class zeroException : Exception
        {
            public zeroException() : base("Must be greater then 0")
            {

            }
        }


    }
}
