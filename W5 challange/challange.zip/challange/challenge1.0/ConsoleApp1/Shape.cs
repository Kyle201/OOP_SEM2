﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Shape
    {
        public string Color;

        public Shape(string color)
        {
            this.Color = color;
        }

    }
}
